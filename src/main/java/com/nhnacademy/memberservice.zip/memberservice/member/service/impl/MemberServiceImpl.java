package com.nhnacademy.memberservice.member.service.impl;

import com.nhnacademy.memberservice.member.domain.Member;
import com.nhnacademy.memberservice.member.dto.MemberRegisterRequest;
import com.nhnacademy.memberservice.member.dto.MemberResponse;
import com.nhnacademy.memberservice.member.dto.MemberUpdatePasswordRequest;
import com.nhnacademy.memberservice.member.dto.MemberUpdateRequest;
import com.nhnacademy.memberservice.member.exception.MemberEmailNotFoundException;
import com.nhnacademy.memberservice.member.exception.MemberNotFoundException;
import com.nhnacademy.memberservice.member.exception.NewPasswordNotMatchException;
import com.nhnacademy.memberservice.member.exception.PasswordNotMatchException;
import com.nhnacademy.memberservice.member.repository.MemberRepository;
import com.nhnacademy.memberservice.member.service.MemberService;
import com.nhnacademy.memberservice.role.domain.Role;
import com.nhnacademy.memberservice.role.exception.RoleNotFoundException;
import com.nhnacademy.memberservice.role.repository.RoleRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Objects;
import java.util.Optional;

/**
 * 회원 관련 비즈니스 로직을 담당하는 구현 클래스입니다.
 * <p>
 * 회원 등록, 조회, 수정, 삭제 기능을 제공합니다.
 * 모든 메서드는 트랜잭션을 고려하여 설계되어 데이터 정합성을 보장합니다.
 * </p>
 */
@Service
@RequiredArgsConstructor
@Transactional
public class MemberServiceImpl implements MemberService {

    private final MemberRepository memberRepository;
    private final RoleRepository roleRepository;

    /**
     * {@inheritDoc}
     *
     * @throws RoleNotFoundException 기본 역할(USER)을 찾을 수 없습니다.
     */
    @Override
    public MemberResponse registerMember(MemberRegisterRequest request) {
        if (!request.isPasswordValid()) {
            throw new PasswordNotMatchException();
        }

        Role role = roleRepository.findByRoleName(request.getRoleName())
                .orElseThrow(() -> new RoleNotFoundException(request.getRoleName()));

        Member member = Member.ofNewMember(
                role,
                request.getName(),
                request.getEmail(),
                request.getPassword(),
                request.getPhoneNumber()
        );

        Member savedMember = memberRepository.save(member);


        return new MemberResponse(
                savedMember.getMbNo(),
                member.getRole().getRoleName(),
                savedMember.getMbName(),
                savedMember.getMbEmail(),
                savedMember.getPhoneNumber()
        );

    }

    @Override
    public MemberResponse getMemberByMbNo(Long mbNo) {
        Member member = memberRepository.findById(mbNo)
                .orElseThrow(() -> new MemberNotFoundException(mbNo));

        return new MemberResponse(
                member.getMbNo(),
                member.getRole().getRoleName(),
                member.getMbName(),
                member.getMbEmail(),
                member.getPhoneNumber()
        );
    }

    /**
     * {@inheritDoc}
     *
     * @throws MemberNotFoundException 회원이 존재하지 않을 경우 예외 발생
     */
    @Override
    @Transactional(readOnly = true)
    public MemberResponse getMemberByEmail(String mbEmail) {
        Member member = memberRepository.findByMbEmail(mbEmail)
                .orElseThrow(() -> new MemberEmailNotFoundException(mbEmail));

        return new MemberResponse(member.getMbNo(), member.getRole().getRoleName(), member.getMbName(), member.getMbEmail(), member.getPhoneNumber());

    }

    /**
     * {@inheritDoc}
     *
     * @throws MemberNotFoundException  회원이 존재하지 않음
     * @throws IllegalArgumentException 역할이 존재하지 않을 경우
     */
    @Override
    public MemberResponse updateMember(Long mbNo, MemberUpdateRequest request) {
        Member member = memberRepository.findById(mbNo)
                .orElseThrow(() -> new MemberNotFoundException(mbNo));

        member.update(
                request.getName(),
                request.getPhoneNumber()
        );

        Member updated = memberRepository.save(member);

        return new MemberResponse(updated.getMbNo(), updated.getRole().getRoleName(), updated.getMbName(), updated.getMbEmail(), updated.getPhoneNumber());
    }

    /**
     * {@inheritDoc}
     *
     * @throws MemberNotFoundException 회원이 존재하지 않는 경우 예외 발생
     */
    @Override
    public void deleteMember(Long mbNo) {
        Member member = memberRepository.findById(mbNo)
                .orElseThrow(() -> new MemberNotFoundException(mbNo));

        member.withdraw();
    }

    @Override
    public void updatePassword(Long mbNo, MemberUpdatePasswordRequest request) {
        Member member = memberRepository.findById(mbNo)
                .orElseThrow(() -> new MemberNotFoundException(mbNo));

        if (!Objects.equals(member.getMbPassword(), request.getOldPassword())) {
            throw new PasswordNotMatchException();
        }

        if (!request.isPasswordValid()) {
            throw new NewPasswordNotMatchException();
        }

        member.updatePassword(request.getNewPassword());

    }

}
